import React from 'react';

const Home = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Fantasy Friend League</h1>
      <p>Track and compare your football stats with friends.</p>
    </div>
  );
};

export default Home;
